# gta2: performance tuning carried over from the Android ROM (OC5)
for c in 0 4; do P=/sys/devices/system/cpu/cpu$c/cpufreq; echo 1794000 > $P/scaling_max_freq; echo interactive > $P/scaling_governor 2>/dev/null; I=$P/interactive; [ -d $I ] && { echo 10000 > $I/timer_rate; echo 1248000 > $I/hispeed_freq; echo 75 > $I/go_hispeed_load; echo "70 1248000:80 1482000:90" > $I/target_loads; }; done
M=/sys/devices/11400000.mali; echo "400000 25 25" > $M/pm_poweroff 2>/dev/null; echo 25 > $M/js_scheduling_period 2>/dev/null; echo 1 > $M/js_ctx_scheduling_mode 2>/dev/null
echo 2 > /proc/irq/313/smp_affinity; echo 2 > /proc/irq/314/smp_affinity; echo 4 > /proc/irq/234/smp_affinity; echo 4 > /proc/irq/239/smp_affinity; echo 8 > /proc/irq/105/smp_affinity
echo log_kevents > /sys/devices/system/exynos-ss/enabled 2>/dev/null
echo 400000 > /sys/class/devfreq/17000020.devfreq_int/min_freq 2>/dev/null
Q=/sys/block/mmcblk0/queue; echo 0 > $Q/iostats; echo 0 > $Q/add_random; echo 2 > $Q/rq_affinity
echo 100 > /proc/sys/vm/swappiness; echo 0 > /proc/sys/vm/page-cluster; echo 24000 > /proc/sys/vm/extra_free_kbytes 2>/dev/null
# zram swap (lz4) instead of an on-disk swap file
if [ -e /sys/block/zram0 ] && ! grep -q zram0 /proc/swaps; then echo lz4 > /sys/block/zram0/comp_algorithm; echo 8 > /sys/block/zram0/max_comp_streams; echo 1400M > /sys/block/zram0/disksize; mkswap /dev/zram0 >/dev/null && swapon -p 100 /dev/zram0; fi
