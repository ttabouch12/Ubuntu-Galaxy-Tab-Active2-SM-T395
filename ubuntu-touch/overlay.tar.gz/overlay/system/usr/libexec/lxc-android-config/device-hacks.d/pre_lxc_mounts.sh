# gta2: mounts for the android lxc container
mount -t tmpfs android_mnt /var/lib/lxc/android/rootfs/mnt
for d in efs cpefs; do [ -d /android/$d ] && mount -o bind /android/$d /var/lib/lxc/android/rootfs/$d; done
# disable android wifi/bt HALs (linux side manages wifi via wpa_supplicant/NetworkManager)
for f in android.hardware.wifi@1.0-service.rc android.hardware.wifi.supplicant-service.rc hostapd.android.rc android.hardware.bluetooth@1.0-service.rc; do [ -e /android/vendor/etc/init/$f ] && mount -o bind /dev/null /android/vendor/etc/init/$f; done
